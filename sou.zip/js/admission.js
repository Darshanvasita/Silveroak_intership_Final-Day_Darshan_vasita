var ProgramObject = {
    "College Of Engineering & Technology": {
        "Bachelor Of Technology": [
            "Aeronautical Engineering",
            "Civil Engineering",
            "Computer Engineering",
            "Computer Engineering With Cloud Computing",
            "Computer Engineering With Ml & Ai",
            "Computer Science & Engineering (Cyber Security)",
            "Computer Sciences & Biosciences",
            "Electronics & Communication Engineering",
            "Information Technology",
            "Mechanical Engineering",
            "Chemical Engineering",
            "Electrical Engineering",
            "Biotechnology"
        ],
        "Master Of Technology": [
            "Chemical Engineering",
            "Civil Engineering",
            "Computer Engineering",
            "Cyber Security",
            "Electronics & Communication Engineering",
            "Mechanical Engineering"
        ],
        "Diploma In Engineering": [
            "Chemical Engineering",
            "Civil Engineering",
            "Computer Engineering",
            "Electrical Engineering",
            "Information Technology",
            "Mechanical Engineering",
            "Petrochemical Engineering",
            "Waste Management Engineering",
            "Aeronautical Engineering"
        ]
    },
    "College of Humanities & Social Science": {
        "Bachelor Of Arts": [
            "Economics",
            "Psychology",
            "English",
            "Sociology"
        ],
        "Bachelor Of Arts (Hons.)": [
            "Economics",
            "Psychology",
            "English",
            "Sociology"
        ],
        "Bachelor Of Social Work": ["Bachelor Of Social Work"],
        "Master Of Arts": [
            "Economics",
            "English",
            "International Relations",
            "Psychology",
            "Public Governance",
            "Sociology"
        ],
        "Master Of Social Work": ["Master Of Social Work"],
        "Certificate Course": ["Foreign Language Hindi"],
    },
    "College of Computer Application": {
        "Bachelor Of Computer Application": ["Bachelor Of Computer Application (BCA)"],        
        "Bachelor Of Science In Computer Science": [
            "Computer Science (B.Sc. CS)",
        ],
        "Bachelor Of Science In Computer Science & IT": [
            "Computer Science & Information Technology (B.Sc. CS-IT)"
        ],
        "Bachelor Of Science In Data Sciences & AI-ML": [
            "Data Sciences & AI-ML (B.Sc. DS & AI-ML)"
        ],
        "Bachelor Of Science In Information Technology": [
            "Information Technology (B.Sc. IT)"
        ],
        "Integrated Bachelor Of Computer Application": [
            "Integrated Bachelor Of Computer Application"
        ],
        "Master Of Computer Application": [
            "Master Of Computer Application (MCA)"
        ],
        "Master Of Science In Cyber Security & Digital Forensics": [
            "Cyber Security & Digital Forensics (M.Sc. CS-DF)"
        ],
        "Master Of Science In Data Sciences": [
            "Data Sciences (M.Sc. DS)"
        ],
        "Master Of Science In Information Technology": [
            "Information Technology (M.Sc. IT)"
        ],
        "Integrated Master Of Science In Cyber Security & Digital Forensics": [
            "Integrated Master Of Science In Cyber Security & Digital Forensics"
        ],
        "Integrated Master Of Science Information Technology": [
            "Integrated Master Of Science Information Technology"
        ],
        "Post Graduate Diploma In Computer Application": [
            "Post Graduate Diploma in Computer Application",  
        ],
        "Post Graduate Diploma In Cyber Security": [
            "Post Graduate Diploma in Cyber Security",    
        ]
    },
    "Silver Oak Institute of Science (SOIS)": {
        "Bachelor Of Science": [
            "Physics",
            "Chemistry",
            "Mathematics",
            "Microbiology",
            "BioTechnology",
            "Fire Safety And Hazard Management",
            "Statistics"
        ],
        "Bachelor Of Science (Hons.)": [
            "Chemistry",
            "Microbiology"
        ],
        "Master Of Science": [
            "Analytical Chemistry",
            "Biochemistry",
            "BioTechnology",
            "Chemistry",
            "Environment Science",
            "Mathematics",
            "Microbiology",
            "Physics",
            "Statistics"
        ],
        "Post Graduate Diploma In Science": [
            "Post Graduate Diploma In Gis And Remote Sensing"
        ]
    },
    "College of Nursing": {
        "Bachelor Of Nursing": ["Bachelor of Science in Nursing"],
        "Diploma In General Nursing And Midwifery": ["Diploma in General Nursing And Midwifery"]
    },
    "Silver Oak Institute of Management (SOIM)": {
        "Bachelor Of Business Administration": [
            "Finance",
            "Human Resource Management",
            "Marketing",
            "Information Technology (IT)",
            "Operations",
            "Gobal Business"
        ],
        "Bachelor Of Business Administration Under Liberal Studies": [
            "Finance",
            "Human Resource Management",
            "Marketing"
        ],
        "Master Of Business Administration": [
            "Finance & Banking",
            "Human Resource Management",
            "Marketing",
            "International Business",
            "Operations & Logistic Supply Chain Mgt.",
            "Information Technology in Business Analytics",
            "Agro Business",
            "Media",
            "Aviation",
            "Health Care & Hospital Management"
        ],
        "Integrated Master Of Business Administration": [
            "Finance",
            "Human Resource Management",
            "Marketing",
            "Operations",
            "Gobal Business"
        ]
    },
    "College of Commerce": {
        "Bachelor Of Commerce (Hons.)": [
            "Marketing",
            "Account & Finance",
            "Human Resource Management"
        ],
        "Master Of Commerce": [
            "Marketing",
            "Account & Finance",
            "Human Resource Management"
        ],
        "Post Graduate Diploma In Commerce": [
            "Post Graduate Diploma in Commerce (PGDC)"
        ]
    },
    "College of Animation & Multimedia": {
        "Certificate Course In Animation & Multimedia": [
            "Graphics Design",
            "Intro To Gaming With Unity"
        ],
        "Diploma Programme In 3D Animation": [
            "3D Animation"
        ],
        "Diploma Programme In Broadcast Graphics": [
            "Broadcast Graphics"
        ],
        "Diploma Programme In Visual Effects": [
            "Visual Effects (VFX)"
        ],
        "Bachelor Of Science In Media Graphics & Animation": [
            "Bachelor Of Science In Media Graphics & Animation"
        ],
        "Advanced Diploma Programme In Animation & Vfx Specialization": [
            "Animation & VFX Specialization"
        ]
    },
    "College of Vocational Education": {
        "Certificate Course In Vocational Education": [
            "Phlebotomy",
            "Waste Management"
        ],
        "Diploma In Vocational": [
            "Automobile Service & Repair",
            "Media Graphics & Animation",
            "Medical Lab Technician",
            "Health Sanitary Inspector",
            "General Duty Assistant"
        ],
        "Bachelor Of Vocational": [
            "Aircraft Maintenance",
            "Animation & Multimedia",
            "Aviation Management",
            "Banking, Financial Services And Insurance",
            "Digital & Internet Marketing",
            "Digital Sound Engineering",
            "Event Management",
            "Fashion Design And Styling",
            "Hotel Management",
            "Information Technology And Information Technology Enabled Services",
            "Interior Design And Styling",
            "IT Infrastructure Management & Cloud Computing",
            "Management & Entrepreneurship And Professional Skills",
            "Media Graphics & Animation",
            "Medical Laboratory Technician",
            "Patient Care Management"
        ],
        "Integrated Bachelor Of Vocational": [
            "IT Infrastructure Management & Cloud Computing"
        ],
        "Master Of Vocational": [
            "Hotel Management"
        ],
        "Post Graduation Diploma In Vocational": [
            "Medical Laboratory Technology (PGDMLT)",
            "Artificial Intelligence",
            "Machine Learning",
            "Robotics"
        ]
    },
    "College of Media & Mass Communication": {
        "Master Of Arts In Media Mass Communication": [
            "Master Of Arts In Media Mass Communication"
        ]
    },
    "Silver Oak Institute of Design (SOID)": {
        "Diploma In Design": [
            "Communication Design", 
            "Product Design", 
            "Fashion Design & Styling",
            "Interior Design"
        ],
        "Bachelor Of Design": [
            "Communication Design", 
            "Product Design", 
            "Fashion Design & Styling", 
            "Interior Design"
        ]
    },
    "College of Physiotherapy": {
        "Bachelor Of Physiotherapy": [
            "Bachelor of Physiotherapy"
        ]
    },
    "Silver Oak Institute Of Aviation": {
        "Certificate Course In Aircraft Maintenance Engineering": [
            "Avionics",
            "Mechanical"
        ],
        "Certificate Course In Aviation": [
            "Airport Management",
            "Cabin Crew"
        ],
        "Bachelor Degree In Aviation": [
            "Bachelor Of Business Administration In Aviation",
            "Bachelor Of Science In Aircraft Maintenance"
        ],
        "Masters In Aviation": [
            "Master Of Business Administration In Aviation"
        ],
    },
    "College of Paramedical": {
        "Post Graduate Diploma In Paramedical": [
            "Medical Laboratory Technology (PGDMLT)"
        ]
    },
    /*
    "Centre for Research": {
        "Doctor Of Philosophy - Full Time": [
            "Humanities & Social Sciences",
            "Management",
            "Science",
            "Technology",
            "Computer application"
        ],
        "Doctor Of Philosophy - Part Time": [
            "Humanities & Social Sciences",
            "Management",
            "Science",
            "Technology",
            "Computer application"
        ]
    },
    "Certificate Course": {
        "Certificate Course": [
            "Accounting and role of accountants",
            "Introduction to SAP & ERP",
            "Entrepreneurship"
        ]
    },
    "SAP Global Certifications": {
        "SAP Technical Module": [
            "SAP ABAP"
        ],
        "SAP Functional Modules": [
            "SAP FI (Finance)", 
            "SAP SD (Sales & Distribution)", 
            "SAP MM (Material Management)", 
            "SAP HCM (Human Capital Management)",
            "SAP PP (Production Planning"
        ]
    }
    */
};
window.onload = function() {
    var countySel = document.getElementById("program"),
        stateSel = document.getElementById("course"),
        districtSel = document.getElementById("coursename");
    for (var country in ProgramObject) {
        countySel.options[countySel.options.length] = new Option(
            country,
            country
        );
    }
    countySel.onchange = function() {
        //document.getElementById("checkboxes").innerHTML = "";
        window.localStorage.removeItem("courses");
        stateSel.length = 1; // remove all options bar first
        districtSel.length = 1; // remove all options bar first
        if (this.selectedIndex < 1) return; // done
        for (var state in ProgramObject[this.value]) {
            stateSel.options[stateSel.options.length] = new Option(
                state,
                state
            );
        }
    };
    countySel.onchange(); // reset in case page is reloaded
    stateSel.onchange = function() {
        //document.getElementById("option").innerHTML = "Select Course Option*";
        window.localStorage.removeItem("courses");
        districtSel.length = 1; // remove all options bar first
        if (this.selectedIndex < 1) return; // done
        var district = ProgramObject[countySel.value][this.value];
        var options = "";
        for (var i = 0; i < district.length; i++) {
            districtSel.options[districtSel.options.length] = new Option(
                district[i],
                district[i]
            );
            //     options +=
            //         '  <label for="' +
            //         district[i] +
            //         '"><input name="coursename[]" value="' +
            //         district[i] +
            //         '" class="select" type="checkbox" data-id="' +
            //         district[i] +
            //         "-" +
            //         i +
            //         '" /><span>' +
            //         district[i] +
            //         "</span></label> <hr />";
        }
        // document.getElementById("checkboxes").innerHTML = options;
    };

    document.getElementById;
};