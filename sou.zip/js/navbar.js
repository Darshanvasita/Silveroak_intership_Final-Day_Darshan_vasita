jQuery(document).ready(function ($) {
  // variables
  var Options, get_options;
  // object
  Options = (function () {
    // constructor
    function Options(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x,
      y, z) {
      this.logo_align = a;
      this.links_align = b;
      this.socialBar_align = c;
      this.searchBar_align = d;
      this.trigger = e;
      this.effect = f;
      this.effect_speed = g;
      this.sibling = h;
      this.outside_click_close = i;
      this.top_fixed = j;
      this.sticky_header = k;
      this.sticky_header_height = l;
      this.menu_position = m;
      this.full_width = n;
      this.color_change = o;
      this.color_button = p;
    }

    // object classes
    Options.prototype.optionsChange = function () {
      // menu initialize
      $('#menu-1').megaMenu({
        // DESKTOP MODE SETTINGS
        logo_align: this.logo_align,
        links_align: this.links_align,
        socialBar_align: this.socialBar_align,
        searchBar_align: this.searchBar_align,
        trigger: this.trigger,
        effect: this.effect,
        effect_speed: 400,
        sibling: true,
        outside_click_close: true,
        top_fixed: this.top_fixed,
        sticky_header: this.sticky_header,
        sticky_header_height: 200,
        menu_position: this.menu_position,
        full_width: false,
        // MOBILE MODE SETTINGS
        mobile_settings: {
          collapse: true,
          sibling: true,
          scrollBar: true,
          scrollBar_height: 400,
          top_fixed: false,
          sticky_header: false,
          sticky_header_height: 200
        }
      });
    };

    // color change function
    Options.prototype.colorChange = function (selector, color) {
      $(selector).click(function () {
        $('#menu-1').attr('data-color', color);
      })
    };

    // return options
    return Options;
  })();

  // call object
  get_options = new Options();
  // call options change
  get_options.optionsChange();
  // call color change function
  get_options.colorChange();
});